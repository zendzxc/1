#!/usr/bin/env python3

from brain_games.gcd import find_gcd


def main():
    print("Welcome to the Brain Games!")
    find_gcd()


if __name__ == '__main__':
    main()