#!/usr/bin/env python3

from brain_games.calc import calc_operations


def main():
    print("Welcome to the Brain Games!")
    calc_operations()


if __name__ == '__main__':
    main()